<?php
	$errormessage='';
	if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	session_start();
    
	if(isset($_POST["name"])){
		$username=$_POST["name"] ;
	}
	
//	if(isset($_SESSION['username'])){
//		$username=$_SESSION['username'];
//	}else{
//		$username='';
//	}
	
	$host = "localhost";
    $port = "5432";
    $dbname = "db_201920z_gv_ind_179";
    $user = "u173220";
    $password = "173220"; 
    $connection_string = "host={$host} port={$port} dbname={$dbname} user= 
              {$user} password={$password} ";
    $dbconn = pg_connect($connection_string);   
  
if($dbconn){
   // echo "Connected established". pg_host($dbconn); 
	$sql = "select ime,prezime, broj from project.korisnik where ime='".$username."' ;";
	//die($sql);
	$result = pg_query($dbconn, $sql);
	if(!$result){
	echo "Somethng went wrong.";
	}  
	$arr = pg_fetch_all($result);
	//die(serialize($arr));
	if ($arr){
	setcookie("username", $username, time()+86400);
	setcookie("surname", $arr[0]['prezime'], time()+86400);
	header("Location: http://localhost:8080/rezervacii.php");
	die();
	}
	$errormessage='Bad Login';
  }
  else {
  echo "Connection Bad";
  }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Create Record</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        .wrapper{
            width: 500px;
            margin: 0 auto;
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header">
                        <h2>Login USER</h2>
                    </div>               
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                        <div class="form-group"><?php echo $errormessage ; ?></div>
						<div class="form-group">
                            <label>Name</label>
                            <input type="text" name="name" class="form-control" value="">
                     
                        </div>
                        <div class="form-group">
                            <label>Password</label>
                            <input type="text" name="password" class="form-control" value="">
                            
                        </div>
                        <input type="submit" class="btn btn-primary" value="Submit">
                    </form>
                </div>
            </div>        
        </div>
    </div>
</body>
</html>

