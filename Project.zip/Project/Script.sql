
insert into Administrator values (
'Bojana Boshkova', 'Bojana','adminpas');
insert into Administrator values ('Angela Shalievska', 'angela.s@gmail.com', 'najdobra');
insert into Administrator values ('Davor Colovik', 'davorcolovik@icloud.com', 'davor1234');

insert into hoteli values ('Park hotel','slika','Lokalen hotel', '0230675148', 'Skopje', 1500, 'ednokrevetna', 'pravila', 'uslugi', ' 1732 street no.4', 'Bojana Boshkova', 'boskovab@mail.com');
insert into hoteli values ('Marriott','slika', 'luksuzen hotel', '03511468', 'Paris', '4000', 'ednokrevetna', 'pravila',  'uslugi', '16 Boulevard Haussmann Paris', 'Angela Shalievska', 'angela.s@gmail.com');
insert into hoteli values ('Ibis','slika ', 'budget hotel', 022534700, 'Amsterdam', 580, 'ednokrevetna', 'pravila',  'uslugi', ' Burgwallen-Nieuwe Zijde', 'Davor Colovik', 'davorc@icloud.com');

insert into e_od values('Park hotel', 'Skopje');
insert into e_od values('Marriott', 'Paris');
insert into e_od values('Ibis', 'Amsterdam');

insert into korisnik values ('boskovab@mail.com', 'Bojana', 071523684, 'Boskova', 'Bojana Boshkova');
insert into korisnik values ('angela.s@gmail.com', 'Angela', 071523684, 'Shalievska', 'Angela Shalievska');
insert into korisnik values ( 'davorc@icloud.com', 'Davor', 071523684, 'Colovik', 'Davor Colovik');

insert into gradovi values ('Skopje', 'Makedonija', 'Park hotel');
insert into gradovi values ('Paris', 'France', 'Marriott');
insert into gradovi values ('Amsterdam', 'Holandija', 'Ibis');

insert into Rezervacii values(1, 'Park hotel', '03.12', '29.11', 6000, 25, 'Bojana Boshkova', 'boskovab@mail.com');
insert into Rezervacii values(2, 'Marriott', 0312, 2911, 12082019, 20000, 52, 'Angela Shalievska', 'angela.s@gmail.com');
insert into Rezervacii values(3, 'Ibis', 0312, 2911, 12082019, 6000, 56, 'Davor Colovik', 'davorc@icloud.com' );


create table Rezervacii(
br_rezervacii varchar(30) primary key,
hotel varchar(30),
datum_od date,
datum_do date,
cena integer, 
soba varchar(30),
korisnik varchar (30),
mail varchar(30),
korisnicko_ime varchar(30),
foreign key(mail) references Korisnik,
foreign key(korisnicko_ime)  references Administrator



);