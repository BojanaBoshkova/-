<?php

	$tabela='';
	$hotelname='';
	$datumod='';
	$datumdo='';
	$sobatip='';
	//konekcija so baza
	$host = "localhost";
    $port = "5432";
    $dbname = "db_201920z_gv_ind_179";
    $user = "u173220";
    $password = "173220"; 
    $connection_string = "host={$host} port={$port} dbname={$dbname} user={$user} password={$password} ";
    $dbconn = pg_connect($connection_string);   


	if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	session_start();
    
	if(isset($_POST["hotel"]) && $_POST["hotel"]<>'-1'){
		$hotelname=$_POST["hotel"] ;
	}
	if(isset($_POST["sobatip"]) && $_POST["sobatip"]<>'-1' ){
		$sobatip=$_POST["sobatip"] ;
	}
	if(isset($_POST["datum_od"]) ){
		$datumod=$_POST["datum_od"] ;
	}
	if(isset($_POST["datum_do"])  ){
		$datumdo=$_POST["datum_do"] ;
	}
	//die($hotelname.$sobatip.$datumod.$datumdo);
	if ($hotelname<>'' && $sobatip<>'' && $datumod<>'' && $datumdo<>'' ){
	// napravi insert vo baza
	$rand = substr(md5(mt_rand()), 0, 7);
	$sql="INSERT INTO project.rezervacii (br_rezervacii, hotel, datum_od, datum_do, cena, soba, korisnik) VALUES('".$rand."', '".$hotelname."', '".$datumod."', '".$datumdo."', 0, '', '".$_POST['user']."');";
	//die($sql);
	$result = pg_query($dbconn, $sql);
	if(!$result){
	echo ('Bad data not inserted');
	}
	
	}
	
  
if($dbconn){
	if($hotelname<>''){
	$sql = "SELECT br_rezervacii, hotel, datum_od, datum_do, cena, soba, korisnik, mail, korisnicko_ime
	FROM project.rezervacii where hotel='".$hotelname."'";
	$result = pg_query($dbconn, $sql);
	if(!$result){
	echo "Somethng went wrong.";
	}  
	$arr = pg_fetch_all($result);
	if (!is_null($arr)){
		// tabela rezervacii
		$tabela='<table class="table">';
		$i=0;
		foreach($arr as $value){
				
				$tabelah='<tr>';
				$tabelad='<tr>';
					foreach($value as $key=>$val){
					if($i==0){
					$tabelah.='<th>'.$key.'</th>';
					$tabelad.='<td>'.$val.'</td>';
					}else{
					$tabelad.='<td>'.$val.'</td>';
					}
					
					}
					$i=1;
				$tabelah.='</tr>';
				$tabelad.='</tr>';
				$tabela.=$tabelah.$tabelad;	
			}
		$tabela.='</table>';
	}
	
	}
	
  }
  else {
  echo "Connection Bad";
  }
}
	$opciite='';
	$sql = "SELECT ime_hotel FROM project.hoteli;";
	$result = pg_query($dbconn, $sql);
	
	if($result){
		$arr = pg_fetch_all($result);
		if (!is_null($arr)){
			$opciite.='<select name="hotel"><option value="-1">select</option>';
			foreach($arr as $val){
				$selected=($hotelname==$val['ime_hotel'])?'selected':'';
			$opciite.='<option value="'.$val['ime_hotel'].'" '.$selected.' >'.$val['ime_hotel'].'</option>';
			}
		$opciite.='</select>';
		}
		}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Hotels list</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        .wrapper{
            width: 500px;
            margin: 0 auto;
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header">
                        <h2>Rezerviraj</h2>
                    </div>               
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
					<div class="form-group">
					  <label>Izberi Hotel:</label>
					<?php echo $opciite; ?>	
					</div>
                        <div class="form-group">
                            <label>Datum od</label>
							<input type="text" name="datum_od" class="form-control" value="">	
							<label>Datum do</label>
                            <input type="text" name="datum_do" class="form-control" value="">    
                       </div>
                        <div class="form-group">
                                               
                        </div>
						<div class="form-group">
                            <label>Soba tip</label>
                        	<select name="sobatip">
								<option value="-1">select</option>
								<option value="ednokrevetna">Ednokrevetna</option>
								<option value="dvokrevetna">Dvokrevetna</option>
								<option value="trokrevetna">Trokrevetna</option>
								<option value="cetvorokrevetna">Cetvorokrevetna</option>
							</select>
							 <input type="hidden"   name="user" value="<?php echo $_COOKIE['username'] ?>">>
                        <input type="submit" class="btn btn-primary" value="Submit">
						</div>
                    </form>
					<div class="form-group">
					<?php echo $tabela; ?>	
					</div>
                
            </div>        
        </div>
    </div>
</body>
</html>

